import { Component, OnInit } from '@angular/core';
import { CourseService, Course } from '../../core/course.service';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  allCourses: Course[]      = [];
  enrolledCourses: Course[] = [];
  studentName = '';
  role = '';

  get totalEnrolled() { return this.enrolledCourses.length; }
  get avgProgress() {
    if (!this.enrolledCourses.length) return 0;
    const sum = this.enrolledCourses.reduce((acc, c) => acc + c.progress, 0);
    return Math.round(sum / this.enrolledCourses.length);
  }
  get completedCount() {
    return this.enrolledCourses.filter(c => c.progress === 100).length;
  }

  constructor(private courseService: CourseService, private authService: AuthService) {}

  ngOnInit() {
    // Subscribe to the BehaviorSubject — updates automatically when courses change
    this.courseService.courses$.subscribe(courses => {
      this.allCourses      = courses;
      this.enrolledCourses = courses.filter(c => c.enrolled);
    });

    this.authService.currentUser$.subscribe(user => {
      this.studentName = user?.name ?? '';
      this.role        = user?.role ?? '';
    });
  }
}
