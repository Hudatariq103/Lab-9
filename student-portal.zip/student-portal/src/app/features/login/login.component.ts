import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email    = '';
  password = '';
  errorMsg = '';
  loading  = false;

  // Demo credentials shown on the page so marker can test easily
  demoAccounts = [
    { label: 'Student', email: 'student@portal.com', password: 'student123' },
    { label: 'Admin',   email: 'admin@portal.com',   password: 'admin123'   }
  ];

  constructor(private authService: AuthService, private router: Router) {}

  fillDemo(account: { email: string; password: string }) {
    this.email    = account.email;
    this.password = account.password;
    this.errorMsg = '';
  }

  onLogin() {
    if (!this.email || !this.password) {
      this.errorMsg = 'Please enter both email and password.';
      return;
    }

    this.loading = true;
    this.errorMsg = '';

    // Small timeout to simulate a real API call
    setTimeout(() => {
      const error = this.authService.login(this.email, this.password);
      this.loading = false;

      if (error) {
        this.errorMsg = error;
      } else {
        this.router.navigate(['/dashboard']);
      }
    }, 600);
  }
}
