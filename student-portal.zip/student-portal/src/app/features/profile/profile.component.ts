import { Component, OnInit } from '@angular/core';
import { AuthService, User } from '../../core/auth.service';
import { CourseService, Course } from '../../core/course.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: User | null = null;
  enrolledCourses: Course[] = [];

  constructor(private authService: AuthService, private courseService: CourseService) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(u => this.user = u);
    this.courseService.courses$.subscribe(courses => {
      this.enrolledCourses = courses.filter(c => c.enrolled);
    });
  }

  get overallProgress() {
    if (!this.enrolledCourses.length) return 0;
    return Math.round(
      this.enrolledCourses.reduce((sum, c) => sum + c.progress, 0) / this.enrolledCourses.length
    );
  }
}
