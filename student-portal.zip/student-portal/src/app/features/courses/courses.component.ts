import { Component, OnInit } from '@angular/core';
import { CourseService, Course } from '../../core/course.service';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  allCourses: Course[] = [];
  searchText  = '';
  sortField   = 'name';
  sortOrder: 'asc' | 'desc' = 'asc';
  enrollMsg   = '';
  isAdmin     = false;

  // Add-course form fields
  showForm    = false;
  newName       = '';
  newInstructor = '';
  newCategory   = '';
  formError     = '';

  // Pagination
  currentPage  = 1;
  pageSize     = 3;

  get totalPages() {
    return Math.ceil(this.allCourses.length / this.pageSize);
  }

  get pages() {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  constructor(private courseService: CourseService, private authService: AuthService) {}

  ngOnInit() {
    this.courseService.courses$.subscribe(c => {
      this.allCourses  = c;
      this.currentPage = 1;
    });
    this.authService.currentUser$.subscribe(u => {
      this.isAdmin = u?.role === 'admin';
    });
  }

  enroll(course: Course) {
    if (course.enrolled) return;
    this.courseService.enroll(course.id);
    this.enrollMsg = `✅ Successfully enrolled in "${course.name}"!`;
    setTimeout(() => this.enrollMsg = '', 3000);
  }

  toggleSort(field: string) {
    if (this.sortField === field) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = field;
      this.sortOrder = 'asc';
    }
    this.currentPage = 1;
  }

  addCourse() {
    if (!this.newName || !this.newInstructor || !this.newCategory) {
      this.formError = 'All fields are required.';
      return;
    }
    this.courseService.addCourse(this.newName, this.newInstructor, this.newCategory);
    this.newName = this.newInstructor = this.newCategory = this.formError = '';
    this.showForm = false;
  }

  goToPage(p: number) {
    this.currentPage = p;
  }
}
