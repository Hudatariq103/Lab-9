import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './core/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isLoggedIn = false;
  studentName = '';

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    // Keep nav bar in sync whenever login state changes
    this.authService.currentUser$.subscribe(user => {
      this.isLoggedIn = !!user;
      this.studentName = user ? user.name : '';
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
