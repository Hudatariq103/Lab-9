import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from './pipes/filter.pipe';
import { SortPipe } from './pipes/sort.pipe';
import { ProgressColorPipe } from './pipes/progress-color.pipe';

// SharedModule bundles reusable pipes and common Angular modules.
// Feature modules import SharedModule instead of repeating these imports individually.
@NgModule({
  declarations: [FilterPipe, SortPipe, ProgressColorPipe],
  imports: [CommonModule, FormsModule],
  exports: [
    CommonModule,
    FormsModule,
    FilterPipe,
    SortPipe,
    ProgressColorPipe
  ]
})
export class SharedModule {}
