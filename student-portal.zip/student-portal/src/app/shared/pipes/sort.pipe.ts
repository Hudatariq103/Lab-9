import { Pipe, PipeTransform } from '@angular/core';

// Custom sorting pipe.
// Usage: courses | sort : 'name' : 'asc'
//        courses | sort : 'progress' : 'desc'
@Pipe({ name: 'sort' })
export class SortPipe implements PipeTransform {
  transform(items: any[], field: string, order: 'asc' | 'desc' = 'asc'): any[] {
    if (!items || !field) return items;

    return [...items].sort((a, b) => {
      const valA = typeof a[field] === 'string' ? a[field].toLowerCase() : a[field];
      const valB = typeof b[field] === 'string' ? b[field].toLowerCase() : b[field];

      if (valA < valB) return order === 'asc' ? -1 : 1;
      if (valA > valB) return order === 'asc' ?  1 : -1;
      return 0;
    });
  }
}
