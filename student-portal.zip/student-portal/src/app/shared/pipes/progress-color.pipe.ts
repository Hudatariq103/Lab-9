import { Pipe, PipeTransform } from '@angular/core';

// Returns a CSS class name based on how far along a course is.
// This is a transform pipe — it converts a number into a string used in [ngClass].
// Usage: [ngClass]="course.progress | progressColor"
@Pipe({ name: 'progressColor' })
export class ProgressColorPipe implements PipeTransform {
  transform(progress: number): string {
    if (progress >= 80) return 'progress-high';    // green
    if (progress >= 40) return 'progress-medium';  // orange
    return 'progress-low';                          // red
  }
}
