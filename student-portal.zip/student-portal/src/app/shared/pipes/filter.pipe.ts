import { Pipe, PipeTransform } from '@angular/core';

// Custom pipe: filters an array of courses by a search string.
// Usage in template: courses | filter : searchText
@Pipe({ name: 'filter' })
export class FilterPipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
    if (!items || items.length === 0) return [];
    if (!searchText || searchText.trim() === '') return items;

    const query = searchText.toLowerCase().trim();

    // Check both course name AND instructor for a more useful search
    return items.filter(item =>
      item.name.toLowerCase().includes(query) ||
      item.instructor?.toLowerCase().includes(query) ||
      item.category?.toLowerCase().includes(query)
    );
  }
}
