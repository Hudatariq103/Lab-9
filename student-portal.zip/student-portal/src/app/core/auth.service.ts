import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface User {
  name: string;
  email: string;
  role: 'student' | 'admin';
}

// Simulated user database — in a real app this would come from a backend API
const USERS = [
  { email: 'student@portal.com', password: 'student123', name: 'Ali Raza',    role: 'student' as const },
  { email: 'admin@portal.com',   password: 'admin123',   name: 'Dr. Fatima',  role: 'admin'   as const }
];

@Injectable({ providedIn: 'root' })
export class AuthService {
  // BehaviorSubject keeps the latest logged-in user and broadcasts it to all subscribers
  private userSubject = new BehaviorSubject<User | null>(this.loadUserFromStorage());
  currentUser$ = this.userSubject.asObservable();

  // ------------------------------------------------------------------
  // Attempt login — returns an error message string or null on success
  // ------------------------------------------------------------------
  login(email: string, password: string): string | null {
    const match = USERS.find(u => u.email === email && u.password === password);
    if (!match) {
      return 'Invalid email or password. Please try again.';
    }
    const user: User = { name: match.name, email: match.email, role: match.role };
    localStorage.setItem('sp_user', JSON.stringify(user));  // Persist session
    this.userSubject.next(user);
    return null; // null = success
  }

  logout() {
    localStorage.removeItem('sp_user');
    this.userSubject.next(null);
  }

  isAuthenticated(): boolean {
    return !!this.userSubject.value;
  }

  getRole(): string {
    return this.userSubject.value?.role ?? '';
  }

  // Restore user from localStorage when the app reloads
  private loadUserFromStorage(): User | null {
    const raw = localStorage.getItem('sp_user');
    return raw ? JSON.parse(raw) : null;
  }
}
