import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';

// AuthGuard is attached to protected routes in app-routing.module.ts.
// If the user is not logged in, it redirects them to /login instead
// of letting them access the requested page.
@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(): boolean {
    if (this.authService.isAuthenticated()) {
      return true;  // Allow navigation
    }
    this.router.navigate(['/login']);
    return false;   // Block navigation
  }
}
