import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Course {
  id: number;
  name: string;
  instructor: string;
  category: string;
  progress: number;       // 0–100
  enrolled: boolean;
  totalStudents: number;
}

// Default course data stored here — simulates what you'd normally fetch from an API
const DEFAULT_COURSES: Course[] = [
  { id: 1, name: 'Angular Basics',       instructor: 'Dr. Fatima',  category: 'Web',      progress: 30, enrolled: false, totalStudents: 120 },
  { id: 2, name: 'TypeScript Mastery',   instructor: 'Sir Kamran',  category: 'Language', progress: 70, enrolled: true,  totalStudents: 95  },
  { id: 3, name: 'Web Development',      instructor: 'Ms. Ayesha',  category: 'Web',      progress: 50, enrolled: true,  totalStudents: 200 },
  { id: 4, name: 'Data Structures',      instructor: 'Dr. Usman',   category: 'CS Core',  progress: 0,  enrolled: false, totalStudents: 140 },
  { id: 5, name: 'Database Systems',     instructor: 'Sir Hassan',  category: 'CS Core',  progress: 85, enrolled: true,  totalStudents: 110 },
  { id: 6, name: 'Machine Learning 101', instructor: 'Dr. Sana',    category: 'AI',       progress: 10, enrolled: false, totalStudents: 75  },
];

@Injectable({ providedIn: 'root' })
export class CourseService {
  // BehaviorSubject: emits its latest value to any new subscriber immediately
  private coursesSubject = new BehaviorSubject<Course[]>([]);
  courses$ = this.coursesSubject.asObservable();

  constructor() {
    this.loadCourses();  // Trigger on service creation
  }

  // Load from localStorage if available, otherwise use defaults
  loadCourses() {
    const saved = localStorage.getItem('sp_courses');
    const courses = saved ? JSON.parse(saved) : DEFAULT_COURSES;
    this.coursesSubject.next(courses);
  }

  private save(courses: Course[]) {
    localStorage.setItem('sp_courses', JSON.stringify(courses));
    this.coursesSubject.next(courses);
  }

  // Enroll a student in a course
  enroll(courseId: number) {
    const courses = this.coursesSubject.value.map(c =>
      c.id === courseId ? { ...c, enrolled: true } : c
    );
    this.save(courses);
  }

  // Update progress percentage for a course
  updateProgress(courseId: number, progress: number) {
    const courses = this.coursesSubject.value.map(c =>
      c.id === courseId ? { ...c, progress } : c
    );
    this.save(courses);
  }

  // Add a brand-new course (admin feature)
  addCourse(name: string, instructor: string, category: string) {
    const courses = this.coursesSubject.value;
    const newCourse: Course = {
      id: Date.now(),         // Simple unique ID using timestamp
      name,
      instructor,
      category,
      progress: 0,
      enrolled: false,
      totalStudents: 0
    };
    this.save([...courses, newCourse]);
  }

  getEnrolledCourses(): Course[] {
    return this.coursesSubject.value.filter(c => c.enrolled);
  }
}
