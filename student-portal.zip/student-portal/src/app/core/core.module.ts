import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from './auth.service';
import { CourseService } from './course.service';
import { AuthGuard } from './auth.guard';

// CoreModule holds singleton services shared across the whole app.
// It is imported ONLY in AppModule — never in feature modules.
@NgModule({
  imports: [CommonModule],
  providers: [AuthService, CourseService, AuthGuard]
})
export class CoreModule {}
